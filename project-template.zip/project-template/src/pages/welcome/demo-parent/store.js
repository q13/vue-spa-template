/**
 * Demo parent状态管理机
 */
export default {
  state: {},
  getters: {},
  actions: {},
  mutations: {}
};
