<template>
  <div>{{ text }}</div>
</template>
<script>
  export default {
    data: function () {
      return {
        text: 'Demo child'
      };
    }
  }
</script>
