declare module 'vue' {
  declare module.exports: any;
}