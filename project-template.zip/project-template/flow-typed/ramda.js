declare module 'ramda' {
  declare module.exports: any;
}